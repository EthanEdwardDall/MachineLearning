# NumpyAssignment.py
# Ethan Dall
# 09/10/2020
# Machine Learning

# Imports
import numpy as np
import csv

# Gets data from file of choice
def returnData(fileName):
    data = []
    inFile = open(fileName, newline="")
    for rows in csv.DictReader(inFile):
        data.append(rows)
    return data

# Gets the highest gain and its date to return
def findHighestGain(array):
    highestDate = array[0]["Date"]
    highestGain = float(array[0]["High"]) - float(array[0]["Low"])
    for i in array:
        newGain = float(i["High"]) - float(i["Low"])
        if(newGain >= 0):
            if(float(newGain) > float(highestGain)):
                highestGain = newGain
                highestDate = i["Date"]
            
    return highestDate, highestGain

# Gets the lowest loss and its date to return
def findLowestLoss(array):
    lowestDate = array[0]["Date"]
    lowestLoss = float(array[0]["Open"]) - float(array[0]["Close"])
    for i in array:
        newLoss = float(i["Open"]) - float(i["Close"])
        if(newLoss <= 0):
            if(float(newLoss) < float(lowestLoss)):
                lowestDate = i["Date"]
                lowestLoss = newLoss
    
    return lowestDate, lowestLoss

# Gets the highest volume value and its date to return
def findHighestVolume(array):
    volumeDate = array[0]["Date"]
    volumeHigh = float(array[0]["Volume"])
    for i in array:
        newVolume = float(i["Volume"])
        if(float(newVolume) > float(volumeHigh)):
            volumeDate = i["Date"]
            volumeHigh = newVolume
            
    return volumeDate, volumeHigh

# Gets the correct string for the key
def monthSwitchString(i):
    if(i == 0):
        print(" January:")
    elif(i == 1):
        print(" Feburary:")
    elif(i == 2):
        print(" March:")
    elif(i == 3):
        print(" April:")
    elif(i == 4):
        print(" May:")
    elif(i == 5):
        print(" June:")
    elif(i == 6):
        print(" July:")
    elif(i == 7):
        print(" August:")
    elif(i == 8):
        print(" September:")
    elif(i == 9):
        print(" October:")
    elif(i == 10):
        print(" November:")
    else:
        print(" December:")
        
# returns the year and margin found
def mostProfitableYear(array, start):
    profitYear = start
    profitMargin = array[0][0] - array[0][1]
    for year in range(len(array)):
        newMargin = float(array[year][0]) - float(array[year][1])
        if(profitMargin < newMargin):
            profitMargin = newMargin
            profitYear = start + year
            
    return profitYear, profitMargin
    
# Prints the multiDimensional Array
def printMonthlyReport(givenArray):
    for i in range(len(givenArray)):
        print(monthSwitchString(i))
        print(" Average Open Price:", givenArray[i][0])
        print(" Average Close Price:", givenArray[i][1])
        print(" Average Transaction Volume:", givenArray[i][2])
        print(" Average Gain/Loss:", givenArray[i][3], "\n")
        
# Prints the multiDimensional Array
def printAnnualReport(givenArray, startYear, endYear, jump):
    if(jump > 1):
        for i in range(len(givenArray)):
            print((startYear + (i*jump)), "to", (startYear + (i*jump) + jump - 1))
            print(" Average Open Price:", givenArray[i][0])
            print(" Average Close Price:", givenArray[i][1])
            print(" Average Transaction Volume:", givenArray[i][2])
            print(" Average Gain/Loss:", givenArray[i][3], "\n")
    else:
        for i in range(len(givenArray)):
            print(str(startYear + i), "to", str(startYear + i +1))
            print(" Average Open Price:", givenArray[i][0])
            print(" Average Close Price:", givenArray[i][1])
            print(" Average Transaction Volume:", givenArray[i][2])
            print(" Average Gain/Loss:", givenArray[i][3], "\n")

# Gets the average value of all data and prints them
def createMonthlyReport(array, start):
    multiMonth = np.fromfunction(lambda x, y: 0*x+0*y, (12,5))
    
    for time in array:
        currentYear = time["Date"][0:4]
        currentMonth = time["Date"][5:7]
        if(currentYear == str(start)):
            averageOpenPrice = multiMonth[(int(currentMonth)-1)][0] + float(time["Open"])
            averageClosePrice = multiMonth[(int(currentMonth)-1)][1] + float(time["Close"])
            averageTVolume = multiMonth[(int(currentMonth)-1)][2] + float(time["Volume"])
            averageGainLoss = multiMonth[(int(currentMonth)-1)][3] + (float(time["High"]) - float(time["Low"]))
            count = multiMonth[(int(currentMonth)-1)][4] + 1
            multiMonth[(int(currentMonth)-1)][0] = averageOpenPrice
            multiMonth[(int(currentMonth)-1)][1] = averageClosePrice
            multiMonth[(int(currentMonth)-1)][2] = averageTVolume
            multiMonth[(int(currentMonth)-1)][3] = averageGainLoss
            multiMonth[(int(currentMonth)-1)][4] = count
    
    # Apply average
    for i in range(12):
        for j in range(4):
            multiMonth[i][j] = multiMonth[i][j]/multiMonth[i][4]
            
    # Print 
    print("\nMonthly Average", "(" + str(start) + "-" + str(start+1) + "):" )
    printMonthlyReport(multiMonth)
    
    # What months are within Range
    startRange = int(input("Enter the starting Range (e.g. 500, 1000, 1500, etc.): "))
    endRange = int(input("Enter the ending Range (e.g. 500, 1000, 1500, etc.): "))
    for elements in range(len(multiMonth)):    
            if(multiMonth[elements][0] >= startRange and multiMonth[elements][0] <= endRange):
                print(monthSwitchString(elements))
                print("Open Price:", multiMonth[elements][0])

# Will print a report of average values after they have been calculated
def createAnnualReport(array, start, end, jump):
    total = end - start + 1
    multiYear = np.fromfunction(lambda x, y: 0*x+0*y, (int(total/jump),5))
    startYear = array[0]["Date"][0:4]
    stepper = 0
    
    for time in array:
        currentYear = time["Date"][0:4]
        if(int(currentYear) >= start and int(currentYear) <= end):
            if(int(currentYear) < (int(startYear)+jump) and jump > 1):
                newValue = int(stepper)
                averageOpenPrice = multiYear[newValue][0] + float(time["Open"])
                averageClosePrice = multiYear[newValue][1] + float(time["Close"])
                averageTVolume = multiYear[newValue][2] + float(time["Volume"])
                averageGainLoss = multiYear[newValue][3] + (float(time["High"]) - float(time["Low"]))
                count = multiYear[newValue][4] + 1
                multiYear[newValue][0] = averageOpenPrice
                multiYear[newValue][1] = averageClosePrice
                multiYear[newValue][2] = averageTVolume
                multiYear[newValue][3] = averageGainLoss
                multiYear[newValue][4] = count
            elif(jump == 1):
                newValue = int(currentYear) - start
                averageOpenPrice = multiYear[newValue][0] + float(time["Open"])
                averageClosePrice = multiYear[newValue][1] + float(time["Close"])
                averageTVolume = multiYear[newValue][2] + float(time["Volume"])
                averageGainLoss = multiYear[newValue][3] + (float(time["High"]) - float(time["Low"]))
                count = multiYear[newValue][4] + 1
                multiYear[newValue][0] = averageOpenPrice
                multiYear[newValue][1] = averageClosePrice
                multiYear[newValue][2] = averageTVolume
                multiYear[newValue][3] = averageGainLoss
                multiYear[newValue][4] = count
            else:
                startYear = currentYear
                if((len(multiYear)-1) > stepper):
                    stepper += 1
                
    # Apply average
    for i in range(len(multiYear)):
        for j in range(4):
            multiYear[i][j] = multiYear[i][j]/multiYear[i][4]
    
    # Print 
    print("\nAnnual Average:" )
    printAnnualReport(multiYear, start, end, jump)
    
    # Calls the mostProfitableYear method that returns a float value
    profitYear, profitMargin = mostProfitableYear(multiYear, start)
    print("The most profitable year from " + str(start) + " to " + str(end) + ": " + str(profitMargin))

# Puts data called into an NumpyArray
npRows = np.array(returnData("SP500.csv"))

# Calls findHighestGain method to get largest High value
gainDate, gainHigh = findHighestGain(npRows)
print("\nWhat is the highest Gain in the data?:\nDate:", gainDate, "\nGain:", gainHigh)
input("Checkpoint: ")

# Calls findLowestLoss method to get lowest Low value
lowDate, lowLoss = findLowestLoss(npRows)
print("\nWhat is the lowest Loss in the data?:\nDate:", lowDate, "\nLoss:", lowLoss)
input("Checkpoint: ")

# Calls findHighestVolume method to get highes volume value
volumeDate, volumeHigh = findHighestVolume(npRows)
print("\nWhat is the highest transaction volume in the data?:\nDate:", volumeDate, "\nVolume:", volumeHigh)
input("Checkpoint: ")

# Calls createMonthlyReport method to print a list of average values
createMonthlyReport(npRows, 2017)
input("Checkpoint: ")

# Calls createAnnualReport method to print a list of average values
createAnnualReport(npRows, 1950, 2018, 1)
input("Checkpoint: ")
createAnnualReport(npRows, 1950, 2018, 5)