# MLProgram_One.py
# Machine Learning
# 09/27/2020
# Ethan Dall

# imports
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

# Perceptron class
class Perceptron(object):
    
    # Constructor
    def __init__(self, eta = 0.01, n_iter = 50, random = 1):
        self.eta = eta
        self.n_iter = n_iter
        self.random = random
        
    # This method is the test which puts outputs an error list and updated weights
    def test(self, X, y):
        
        # Get a random number, Assign weight to the normilization of the random number
        ranNum = np.random.RandomState(self.random)
        self.weight = ranNum.normal(loc=0.0, scale=0.01, size=1 + X.shape[1])
        
        # Go through the test samples and determine their correctness
        self.errorList = []
        for non in range(self.n_iter):
            errors = 0
            for xi, target in zip(X, y):
                update = self.eta * (target - self.prediction(xi))
                self.weight[1:] += update * xi
                self.weight[0] += update
                errors += int(update != 0.0)
            self.errorList.append(errors)
        return self
                
    # This method add the current weight with the value provides
    def net_input(self, X):
        return np.dot(X, self.weight[1:]) + self.weight[0]
    
    # This method predicts what the weight is based on test value
    def prediction(self, X):
        return np.where(self.net_input(X) >= 0.0, 1, -1)
    
# Adaline class
class AdalineGD(object):
    
    # Constructor
    def __init__(self, eta = 0.1, n_iter = 50, random = 1):
        self.eta = eta
        self.n_iter = n_iter
        self.random = random
        
    # This method is the test which the gradient and update weights
    def test(self, X, y):
        
        # Assign a random number then normalize
        ranNum = np.random.RandomState(self.random)
        self.weight = ranNum.normal(loc=0.0, scale=0.01, size=1 + X.shape[1])
        
        # Finds the updates weight, then processes the answer into an output value
        # This output value is calculated into an error value to be processed through
        #    each variation of weight and cost to then get added to the costList
        self.costList = []
        for i in range(self.n_iter):
            net_input = self.net_input(X)
            output = self.activation(net_input)
            errors = (y - output)
            self.weight[1:] += self.eta * X.T.dot(errors)
            self.weight[0] += self.eta * errors.sum()
            cost = (errors**2).sum() / 2.0
            self.costList.append(cost)
        return self

    # This method adds up all the weights before this new one, then adds the new value
    def net_input(self, X):
        """Calculate net input"""
        return np.dot(X, self.weight[1:]) + self.weight[0]

    # This method returns the value of X
    def activation(self, X):
        """Compute linear activation"""
        return X

    # This method calls to get value of X to be compared and return result
    def predict(self, X):
        """Return class label after unit step"""
        return np.where(self.activation(self.net_input(X)) >= 0.0, 1, -1)
        
    
# This is the test for perceptron learning
def runTestAmountP(value, totalLength):    
    # Data gathering for the test answers and values
    y = df.iloc[0:int(totalLength*value), 4].values
    y = np.where(y == 1, -1, 1)
    X = df.iloc[0:int(totalLength*value), [0, 3]].values
    
    # Call test
    perceptron = Perceptron(eta = 0.1, n_iter = 50)
    perceptron.test(X, y)
    
    # Create a graph showing the updates based on epoch change
    plt.plot(range(1, len(perceptron.errorList) + 1), perceptron.errorList, marker='o')
    plt.xlabel('Epochs' + " Size(" + str(totalLength*value) + ")")
    plt.ylabel('Number of updates')
    plt.show()
    
# This is the test for adaline learning
def runTestAmountA(value, totalLength):
    # Assigns the values to y and X based on the data given
    y = df.iloc[0:int(totalLength*value), 4].values
    y = np.where(y == 1, -1, 1)
    X = df.iloc[0:int(totalLength*value), [0, 3]].values
    
    # Creates the plots for the upcoming values
    fig, ax = plt.subplots(nrows=1, ncols=2, figsize=(10, 4))
    
    # Figure 1; calls the adaline class and specifies its learning rate and interval size
    ada1 = AdalineGD(n_iter=10, eta=0.01).test(X, y)
    ax[0].plot(range(1, len(ada1.costList) + 1), np.log10(ada1.costList), marker='o')
    ax[0].set_xlabel('Epochs' + " Size(" + str(totalLength*value) + ")")
    ax[0].set_ylabel('log(Sum-squared-error)')
    ax[0].set_title('Adaline - Learning rate 0.01')
    
    ada2 = AdalineGD(n_iter=10, eta=0.0001).test(X, y)
    ax[1].plot(range(1, len(ada2.costList) + 1), ada2.costList, marker='o')
    ax[1].set_xlabel('Epochs' + " Size(" + str(totalLength*value) + ")")
    ax[1].set_ylabel('Sum-squared-error')
    ax[1].set_title('Adaline - Learning rate 0.0001')
    
    plt.show()

# This is the test for perceptron learning
def runTestNterP(value):    
    # Data gathering for the test answers and values
    y = df.iloc[0:100, 4].values
    y = np.where(y == 1, -1, 1)
    X = df.iloc[0:100, [0, 3]].values
    
    # Call test
    perceptron = Perceptron(eta = 0.1, n_iter = value)
    perceptron.test(X, y)
    
    # Create a graph showing the updates based on epoch change
    plt.plot(range(1, len(perceptron.errorList) + 1), perceptron.errorList, marker='o')
    plt.xlabel('Epochs' + " N_iter(" + str(value) + ")")
    plt.ylabel('Number of updates')
    plt.show()
    
# This is the test for adaline learning
def runTestNterA(value):
    # Assigns the values to y and X based on the data given
    y = df.iloc[0:100, 4].values
    y = np.where(y == 1, -1, 1)
    X = df.iloc[0:100, [0, 3]].values
    
    # Creates the plots for the upcoming values
    fig, ax = plt.subplots(nrows=1, ncols=2, figsize=(10, 4))
    
    # Figure 1; calls the adaline class and specifies its learning rate and interval size
    ada1 = AdalineGD(n_iter=value, eta=0.01).test(X, y)
    ax[0].plot(range(1, len(ada1.costList) + 1), np.log10(ada1.costList), marker='o')
    ax[0].set_xlabel('Epochs' + " N_iter(" + str(value) + ")")
    ax[0].set_ylabel('log(Sum-squared-error)')
    ax[0].set_title('Adaline - Learning rate 0.01')
    
    ada2 = AdalineGD(n_iter=value, eta=0.0001).test(X, y)
    ax[1].plot(range(1, len(ada2.costList) + 1), ada2.costList, marker='o')
    ax[1].set_xlabel('Epochs' + " N_iter(" + str(value) + ")")
    ax[1].set_ylabel('Sum-squared-error')
    ax[1].set_title('Adaline - Learning rate 0.0001')
    
    plt.show()
    
# This is the test for perceptron learning
def runTestETAP(value):    
    # Data gathering for the test answers and values
    y = df.iloc[0:100, 4].values
    y = np.where(y == 1, -1, 1)
    X = df.iloc[0:100, [0, 3]].values
    
    # Call test
    perceptron = Perceptron(eta = value, n_iter = 50)
    perceptron.test(X, y)
    
    # Create a graph showing the updates based on epoch change
    plt.plot(range(1, len(perceptron.errorList) + 1), perceptron.errorList, marker='o')
    plt.xlabel('Epochs' + " ETA(" + str(value) + ")")
    plt.ylabel('Number of updates')
    plt.show()
    
# This is the test for adaline learning
def runTestETAA(value):
    # Assigns the values to y and X based on the data given
    y = df.iloc[0:100, 4].values
    y = np.where(y == 1, -1, 1)
    X = df.iloc[0:100, [0, 3]].values
    
    # Creates the plots for the upcoming values
    fig, ax = plt.subplots(nrows=1, ncols=2, figsize=(10, 4))
    
    # Figure 1; calls the adaline class and specifies its learning rate and interval size
    ada1 = AdalineGD(n_iter=10, eta=value).test(X, y)
    ax[0].plot(range(1, len(ada1.costList) + 1), np.log10(ada1.costList), marker='o')
    ax[0].set_xlabel('Epochs')
    ax[0].set_ylabel('log(Sum-squared-error)')
    ax[0].set_title('Adaline - Learning rate ' + str(value))
    
    ada2 = AdalineGD(n_iter=10, eta=value*0.01).test(X, y)
    ax[1].plot(range(1, len(ada2.costList) + 1), ada2.costList, marker='o')
    ax[1].set_xlabel('Epochs')
    ax[1].set_ylabel('Sum-squared-error')
    ax[1].set_title('Adaline - Learning rate ' + str(value*0.01))
    
    plt.show()

# Assign banknotes.data file to dataframe
df = pd.read_csv("data_banknote_authentication.txt", header = None)
totalLength = len(df)-1

"""Perceptron Class tests"""

# Tests if the amount of data changes the number of updates
currentValue = 0.25
for i in range(4):
    runTestAmountP(currentValue, totalLength)
    currentValue += currentValue

# Tests if the change in n_iter changes the number of updates
currentValue = 50
for i in range(4):
    runTestNterP(currentValue)
    currentValue = currentValue * 5

# Tests if the change in eta changes the number of updates
currentValue = 0.1
for i in range(4):
    runTestETAP(currentValue)
    currentValue = currentValue + 0.1
    
"""Adaline Class tests"""

# Tests if the amount of data changes the curve
currentValue = 0.25
for i in range(4):
    runTestAmountA(currentValue, totalLength)
    currentValue += currentValue
    
# Tests if the change in n_iter changes the curve
currentValue = 50
for i in range(4):
    runTestNterA(currentValue)
    currentValue = currentValue * 5
    
# Tests if the change in eta changes the number of updates
currentValue = 0.01
for i in range(4):
    runTestETAA(currentValue)
    currentValue = currentValue * 2