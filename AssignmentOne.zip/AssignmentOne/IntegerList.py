# IntegerList.py
# Ethan Dall
# 09/05/2020
# Machine Learning

# Keeps asking user input for an integer number until a sentinel value is entered
def userInput():
    list = []
    answer = 0
    while(answer != 'quit'):
        try:
            answer = input("Enter a integer (Type 'quit' to end): ")
            value = int(answer)
            list.append(value)
        except ValueError:
            if(answer == 'quit'):
                print("ending loop")
            else:
                print("Your input is invalid")

            
    return list

# Gets the user input
finalList = []
finalList.extend(userInput())

# Seperate the integers based on their value
posList = []
negList = []
for i in finalList:
    if(i < 0):
        negList.append(i)
    else:
        posList.append(i)

# Print both value lists
print("Positive List: ")
print(posList)
print("Negative List: ")
print(negList)

# Check which list has more
if(len(posList) > len(negList)):
    print("The Positive List has more elements")
elif(len(posList) == len(negList)):
    print("Both the Positive List and Negative List have the same amount of elements")
else:
    print("The Negative List has more elements")
        
        
