# dictObjectives.py
# Ethan Dall
# 09/06/2020
# Machine Learning

# Dictionary sample
storage = { 'computer' : 80,
            'furniture' : ['chair', 'table', 'bench'],
            'clothes' : ['shirt', 'jacket', 'vest', 'cotton sweater'] }

# Objective One: Adding the 'shoes' key
storage['shoes'] = ''
print("Objective One:", storage, '\n')

# Objective Two: add list of elements to 'shoes' key
storage['shoes'] = ['sneaker', 'winter sleeper', 'bloc']
print("Objective Two:", storage, '\n')

# Sort the items in the list stored under the 'clothes' key
sortedList = storage['clothes']
sortedList.sort()
storage['clothes'] = sortedList
print("Objective Three:", storage, '\n')

# Remove ('shirt') from the list of items stored under the 'clothes' key
newList = storage['clothes']
newList.remove('shirt')
storage['clothes'] = newList
print("Objective Four:", storage, '\n')

# Add 8 to the number stored under the 'computer' key.
computerValue = storage['computer']
computerValue = computerValue + 8
storage['computer'] = computerValue
print("Objective Five:", storage, '\n')

