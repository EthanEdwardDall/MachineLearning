# palindromeChecker.py
# Ethan Dall
# 09/05/2020
# Machine Learning

# Checks to see if there are more than two letters in the string
def paliCount(x):
    count = 0
    for i in x:
        if(len(i) > 2):
            if(paliCheck(i)):
                count = count + 1
            
    return count

# Checks to see if the string is a palidrome
def paliCheck(x):
    length = len(x)/2
    firstHalf = x[0:int(length)]
    secondHalf = x[:int(length):-1]
    if(firstHalf == secondHalf):
        return True
    else:
        return False

# Sends the list and prints the output of paliCount
list = ['ethte', 'whatthe', 'racecar', 'th', 'whatahw']
count = paliCount(list)

print(list)
print(count)
        
        
