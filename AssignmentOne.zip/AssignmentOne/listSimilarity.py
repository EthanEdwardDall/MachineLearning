# listSimilarity.py
# Ethan Dall
# 09/05/2020
# Machine Learning

def checkSimilarities(x, y):
    similarElements = []
    for i in x:
        for j in y:
            if(i == j):
                similarElements.append(j)
    return similarElements

xList = ['Blue', 'Green', 'Brown', 'Yellow', 'Purple']
yList = ['Red', 'Blue', 'Yellow', 'Orange', 'Black']
similarList = checkSimilarities(xList, yList)

print(xList)
print(yList)
print("Similarities: ")
print(similarList)
