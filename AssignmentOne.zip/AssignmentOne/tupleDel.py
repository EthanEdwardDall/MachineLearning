# tupleDel.py
# Ethan Dall
# 09/06/2020
# Machine Learning

# Sample list of tuples
tupleList = [('a', 'b', 'c', 'd', 'e', 'f'),
             ('g', 'h', 'i', 'j', 'k', 'l'),
             ('m', 'n', 'o', 'p', 'q', 'r'),
             ('s', 't', 'u', 'v', 'w', 'x'),
             ('y', 'z')]

# Deletes any tuple in the list that has a vowel within it
print("Before deletion:", tupleList)
deletionKey = ['a','e','i','o','u']
for i in deletionKey:
    for j in tupleList:
        for k in j:
            if(k == i):
                tupleList.remove(j)

print("After deletion:", tupleList)
