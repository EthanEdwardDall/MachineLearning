# listToDict.py
# Ethan Dall
# 09/06/2020
# Machine Learning

# Takes the list and converts the elements into keys and definitions
def toDict(x):
    returnDict = {}
    keyValue = []
    defValue = []
    keyValue = x[0::2]
    defValue = x[1::2]
    for i in range(len(keyValue)):
        returnDict[keyValue[i]] = defValue[i]

    return returnDict

# Sends List and has a list assigned to the return, then print
finalDict = {}
valueList = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n']
finalDict = toDict(valueList)
print(finalDict)
