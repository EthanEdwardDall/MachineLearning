# KNNAssignment.py
# Ethan Dall
# 10/24/2020
# Machine Learning

# Imports
import numpy as np
import pandas as pd
from pandas import DataFrame
import matplotlib.pyplot as plt
from matplotlib.colors import ListedColormap
from sklearn.metrics import accuracy_score
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.tree import DecisionTreeClassifier
from pydotplus import graph_from_dot_data
from sklearn.tree import export_graphviz
from sklearn import preprocessing
from sklearn.metrics import classification_report
from sklearn.metrics import confusion_matrix
from sklearn import neighbors
import re

# This method determines which regions are highlighted within the graphs
def plot_decision_regions(X, y, classifier, test_idx=None, resolution=0.02):

    # setup marker generator and color map
    markers = ('s', 'x', 'o', '^', 'v')
    colors = ('red', 'blue', 'lightgreen', 'gray', 'cyan')
    cmap = ListedColormap(colors[:len(np.unique(y))])

    # plot the decision surface
    x1_min, x1_max = X[:, 0].min() - 1, X[:, 0].max() + 1
    x2_min, x2_max = X[:, 1].min() - 1, X[:, 1].max() + 1
    xx1, xx2 = np.meshgrid(np.arange(x1_min, x1_max, resolution),
                           np.arange(x2_min, x2_max, resolution))
    Z = classifier.predict(np.array([xx1.ravel(), xx2.ravel()]).T)
    Z = Z.reshape(xx1.shape)
    plt.contourf(xx1, xx2, Z, alpha=0.3, cmap=cmap)
    plt.xlim(xx1.min(), xx1.max())
    plt.ylim(xx2.min(), xx2.max())

    for idx, cl in enumerate(np.unique(y)):
        plt.scatter(x=X[y == cl, 0], 
                    y=X[y == cl, 1],
                    alpha=0.8, 
                    c=colors[idx],
                    marker=markers[idx], 
                    label=cl, 
                    edgecolor='black')

    # highlight test samples
    if test_idx:
        # plot all samples
        X_test, y_test = X[test_idx, :], y[test_idx]

        plt.scatter(X_test[:, 0],
                    X_test[:, 1],
                    c='',
                    edgecolor='black',
                    alpha=1.0,
                    linewidth=1,
                    marker='o',
                    s=100, 
                    label='test set')

# Define function to extract titles from passenger names
def get_title(name):
    title_search = re.search(' ([A-Za-z]+)\.', name)
    # If the title exists, extract and return it.
    if title_search:
        return title_search.group(1)
    return ""
     
""" Main """
# Assign Data
train = pd.read_csv("train.csv")
test = pd.read_csv("test.csv")
full_data = [train, test]

# Re-assign values to 'Name', 'Sex', and 'Embarked'
# Remove all NULLS in the Embarked column
for dataset in full_data:
    dataset['Embarked'] = dataset['Embarked'].fillna('S')

# Remove all NULLS in the Fare column
for dataset in full_data:
    dataset['Fare'] = dataset['Fare'].fillna(train['Fare'].median())

# Remove all NULLS in the Age column
for dataset in full_data:
    age_avg = dataset['Age'].mean()
    age_std = dataset['Age'].std()
    age_null_count = dataset['Age'].isnull().sum()
    age_null_random_list = np.random.randint(age_avg - age_std, age_avg + age_std, size=age_null_count)
    # Next line has been improved to avoid warning
    dataset.loc[np.isnan(dataset['Age']), 'Age'] = age_null_random_list
    dataset['Age'] = dataset['Age'].astype(int)
    
for dataset in full_data:
    dataset['Title'] = dataset['Name'].apply(get_title)
# Group all non-common titles into one single grouping "Rare"
for dataset in full_data:
    dataset['Title'] = dataset['Title'].replace(['Lady', 'Countess','Capt', 'Col','Don', 'Dr', 'Major', 'Rev', 'Sir', 'Jonkheer', 'Dona'], 'Rare')

    dataset['Title'] = dataset['Title'].replace('Mlle', 'Miss')
    dataset['Title'] = dataset['Title'].replace('Ms', 'Miss')
    dataset['Title'] = dataset['Title'].replace('Mme', 'Mrs')

for dataset in full_data:
    # Mapping Sex
    dataset['Sex'] = dataset['Sex'].map( {'female': 0, 'male': 1} ).astype(int)
    
    # Mapping titles
    title_mapping = {"Mr": 1, "Master": 2, "Mrs": 3, "Miss": 4, "Rare": 5}
    dataset['Title'] = dataset['Title'].map(title_mapping)
    dataset['Title'] = dataset['Title'].fillna(0)

    # Mapping Embarked
    dataset['Embarked'] = dataset['Embarked'].map( {'S': 0, 'C': 1, 'Q': 2} ).astype(int)
    
    # Mapping Fare
    dataset.loc[ dataset['Fare'] <= 7.91, 'Fare'] 						        = 0
    dataset.loc[(dataset['Fare'] > 7.91) & (dataset['Fare'] <= 14.454), 'Fare'] = 1
    dataset.loc[(dataset['Fare'] > 14.454) & (dataset['Fare'] <= 31), 'Fare']   = 2
    dataset.loc[ dataset['Fare'] > 31, 'Fare'] 							        = 3
    dataset['Fare'] = dataset['Fare'].astype(int)
    
    # Mapping Age
    dataset.loc[ dataset['Age'] <= 16, 'Age'] 					       = 0
    dataset.loc[(dataset['Age'] > 16) & (dataset['Age'] <= 32), 'Age'] = 1
    dataset.loc[(dataset['Age'] > 32) & (dataset['Age'] <= 48), 'Age'] = 2
    dataset.loc[(dataset['Age'] > 48) & (dataset['Age'] <= 64), 'Age'] = 3
    dataset.loc[ dataset['Age'] > 64, 'Age'] 
    
# Make the list full_data into a DataFrame
title_list = ["PassengerId", "Survived", "Pclass", "Name", "Sex", "Age", "SibSp", "Parch","Ticket", "Fare", "Cabin", "Embarked", "Title"]
frameOne = DataFrame(full_data[0], columns=title_list)
frameTwo = DataFrame(full_data[1], columns=title_list)

# Drop unneeded columns
drop_elements = ['PassengerId', 'Name', 'Ticket', 'Cabin', 'SibSp']
frameOne = frameOne.drop(drop_elements, axis = 1)
frameTwo  = frameTwo.drop(drop_elements, axis = 1)
df = pd.concat([frameOne, frameTwo])

X_train = np.array(frameOne.drop(['Survived'], 1))
y_train = np.array(frameOne['Embarked'])
X_test = np.array(frameTwo.drop(['Survived'], 1))
y_test = np.array(frameTwo['Embarked'])

# Shows the accuracy, confusion matrix and classification report.
forest = RandomForestClassifier(criterion='gini', n_estimators=25, random_state=1, n_jobs=2)


forest.fit(X_train, y_train)
y_pred = forest.predict(X_test)
accuracy = forest.score(X_test, y_test)

print("Random Forest Accuracy:",accuracy)
print(confusion_matrix(y_test, y_pred))
print(classification_report(y_test, y_pred))

# Assess feature importance
feat_labels = df.columns[:-1]
importances = forest.feature_importances_

# Print the importance indices then shape to print based on labels
indices = np.argsort(importances)[::-1]
print(indices)
print(X_train.shape[1])
for f in range(X_train.shape[1]):
    print("%2d) %-*s %f" % (f + 1, 30, 
                            feat_labels[indices[f]], 
                            importances[indices[f]]))
    
# One small decision tree from the random forest, with an explination
# Pull out one tree from the forest
tree = forest.estimators_[5]

# Export the image to a dot data
df1 = df.drop(['Age'], 1)
feature_list = list(df1.columns)
dot_data = export_graphviz(tree, out_file = None, 
                feature_names = feature_list, 
                rounded = True, precision = 1)
# Use dot data to create a graph
graph = graph_from_dot_data(dot_data)
# Create a bar graph that shows the amount of indices for the labels
plt.title('Feature Importance')
plt.bar(range(X_train.shape[1]), 
        importances[indices],
        align='center')

plt.xticks(range(X_train.shape[1]), 
           feat_labels[indices], rotation=90)
plt.xlim([-1, X_train.shape[1]])
plt.tight_layout()
plt.show()

# Write graph to a png file
graph.write_png('titanic.png'); 

# The top five important features to do a decision tree model analysis
# Create a Tree plot
dot_data = export_graphviz(tree,filled=True,rounded=True,
                           class_names=['0', '1', '2'],
                           feature_names=['Fare', 
                                          'Survived',
                                          'Parch',
                                          'Sex',
                                          'Embarked',
                                          'Age',
                                          'Pclass'],
                           out_file=None) 
graph = graph_from_dot_data(dot_data) 
graph.write_png('FeatureTree.png')

# KNN training and testing; Accuracy, Confusion Matrix and Classification Report.
print()
clf = neighbors.KNeighborsClassifier()
clf.fit(X_train, y_train)
accuracy = clf.score(X_test, y_test)
print("KNN Accuracy:", accuracy)

y_pred = clf.predict(X_test)
print(confusion_matrix(y_test, y_pred))
print(classification_report(y_test, y_pred))