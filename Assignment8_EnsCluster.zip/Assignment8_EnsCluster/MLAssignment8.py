# Ethan Dall
# MLAssignment8.py
# 11/15/2020

# Imports
import numpy as np
import pandas as pd
from sklearn.ensemble import BaggingClassifier
from sklearn.tree import DecisionTreeClassifier
from sklearn.metrics import accuracy_score
import matplotlib.pyplot as plt
from pandas import DataFrame
from numpy import percentile
from sklearn.model_selection import train_test_split
from sklearn.cluster import KMeans

# This method reassigns values to the testing and training values of Competitor, then return the new list
def reassignValues(df):
    data = [df]
    for dataset in data:
        # Mapping titles
        competitor_mapping = {"Bob": 0, "Sue": 1, "Kate": 2, "Mark": 3}
        dataset['Competitor'] = dataset['Competitor'].map(competitor_mapping)
    return data

# Main
df_train = pd.read_csv("train.txt")
df_test = pd.read_csv("test.txt")

# Reassign Competitor data for processing
trainList = reassignValues(df_train)
testList = reassignValues(df_test)

title_list = ["ID", "XCoord", "YCoord", "Competitor"]
df_train = DataFrame(trainList[0], columns=title_list)
df_test = DataFrame(testList[0], columns=title_list)

# Split into Train and Test Data
X_train = df_train.iloc[:, 0:3].values
X_test = df_test.iloc[:, 0:3].values
y_train = df_train.iloc[:, 3].values
y_test = df_test.iloc[:, 3].values

"""Creat a DicisionTree to Bag"""
tree = DecisionTreeClassifier(criterion='entropy', max_depth=None, random_state=1)

bag = BaggingClassifier(base_estimator=tree, n_estimators=500, max_samples=1.0, 
                        max_features=1.0, bootstrap=True, bootstrap_features=False, 
                        n_jobs=1, random_state=1)

# Determine the accuracy score for each classifier
tree = tree.fit(X_train, y_train)
y_train_pred = tree.predict(X_train)
y_test_pred = tree.predict(X_test)

tree_train = accuracy_score(y_train, y_train_pred)
tree_test = accuracy_score(y_test, y_test_pred)
print('Decision tree train/test accuracies %.3f/%.3f' % (tree_train, tree_test))

bag = bag.fit(X_train, y_train)
y_train_pred = bag.predict(X_train)
y_test_pred = bag.predict(X_test)

bag_train = accuracy_score(y_train, y_train_pred) 
bag_test = accuracy_score(y_test, y_test_pred) 
print('Bagging train/test accuracies %.3f/%.3f' % (bag_train, bag_test))

# Show how each classifier is plotted
x_min = X_train[:, 0].min() - 1
x_max = X_train[:, 0].max() + 1
y_min = X_train[:, 1].min() - 1
y_max = X_train[:, 1].max() + 1
z_min = X_train[:, 2].min() - 1
z_max = X_train[:, 2].max() + 1

xx, yy, zz = np.meshgrid(np.arange(x_min, x_max, 0.1),
                     np.arange(y_min, y_max, 0.1),
                     np.arange(z_min, z_max, 0.1))

f, axarr = plt.subplots(nrows=1, ncols=2, 
                        sharex='col', 
                        sharey='row', 
                        figsize=(8, 3))


for idx, clf, tt in zip([0, 1],
                        [tree, bag],
                        ['Decision tree', 'Bagging']):
    clf.fit(X_train, y_train)

    axarr[idx].scatter(X_train[y_train == 0, 0],
                       X_train[y_train == 0, 1],
                       c='blue', marker='^')

    axarr[idx].scatter(X_train[y_train == 1, 0],
                       X_train[y_train == 1, 1],
                       c='green', marker='o')
    
    axarr[idx].scatter(X_train[y_train == 2, 0],
                       X_train[y_train == 2, 1],
                       c='red', marker='x')

    axarr[idx].set_title(tt)

axarr[0].set_ylabel('Y', fontsize=12)
plt.text(10.2, -0.5,
         s='X',
         ha='center', va='center', fontsize=12)
plt.tight_layout()
plt.show()

"""Elbow method Clustering"""
# Assign Data
true_data = pd.read_csv("wine.csv")

# Data preprocessing
# Remove any missing values
true_data.dropna(axis=1)

# Mapping each feature from the new list
listData = [true_data]
for dataset in listData:
    # calculate quartiles for each feature
    FAMin = dataset['fixed acidity'].min()
    FAQuartiles = percentile(dataset['fixed acidity'], [25, 50, 75])
    dataset.loc[ dataset['fixed acidity'] <= FAMin, 'fixed acidity'] = 0
    dataset.loc[(dataset['fixed acidity'] > FAQuartiles[0]) & 
                (dataset['fixed acidity'] <= FAQuartiles[1]), 'fixed acidity']= 1
    dataset.loc[(dataset['fixed acidity'] > FAQuartiles[1]) & 
                (dataset['fixed acidity'] <= FAQuartiles[2]), 'fixed acidity']= 2
    dataset.loc[ dataset['fixed acidity'] > FAQuartiles[2], 'fixed acidity'] = 3
    dataset['fixed acidity'] = dataset['fixed acidity'].astype(int)
    
    VAMin = dataset['volatile acidity'].min()
    VAQuartiles = percentile(dataset['volatile acidity'], [25, 50, 75])
    dataset.loc[ dataset['volatile acidity'] <= VAMin, 'volatile acidity'] = 0
    dataset.loc[(dataset['volatile acidity'] > VAQuartiles[0]) & 
                (dataset['volatile acidity'] <= VAQuartiles[1]), 'volatile acidity']= 1
    dataset.loc[(dataset['volatile acidity'] > VAQuartiles[1]) & 
                (dataset['volatile acidity'] <= VAQuartiles[2]), 'volatile acidity']= 2
    dataset.loc[ dataset['volatile acidity'] > VAQuartiles[2], 'volatile acidity'] = 3
    dataset['volatile acidity'] = dataset['volatile acidity'].astype(int)
    
    CAMin = dataset['citric acid'].min()
    CAQuartiles = percentile(dataset['citric acid'], [25, 50, 75])
    dataset.loc[ dataset['citric acid'] <= CAMin, 'citric acid'] = 0
    dataset.loc[(dataset['citric acid'] > CAQuartiles[0]) & 
                (dataset['citric acid'] <= CAQuartiles[1]), 'citric acid']= 1
    dataset.loc[(dataset['citric acid'] > CAQuartiles[1]) & 
                (dataset['citric acid'] <= CAQuartiles[2]), 'citric acid']= 2
    dataset.loc[ dataset['citric acid'] > CAQuartiles[2], 'citric acid'] = 3
    dataset['citric acid'] = dataset['citric acid'].astype(int)
    
    RSMin = dataset['residual sugar'].min()
    RSQuartiles = percentile(dataset['residual sugar'], [25, 50, 75])
    dataset.loc[ dataset['residual sugar'] <= RSMin, 'residual sugar'] = 0
    dataset.loc[(dataset['residual sugar'] > RSQuartiles[0]) & 
                (dataset['residual sugar'] <= RSQuartiles[1]), 'residual sugar']= 1
    dataset.loc[(dataset['residual sugar'] > RSQuartiles[1]) & 
                (dataset['residual sugar'] <= RSQuartiles[2]), 'residual sugar']= 2
    dataset.loc[ dataset['residual sugar'] > RSQuartiles[2], 'residual sugar'] = 3
    dataset['residual sugar'] = dataset['residual sugar'].astype(int)
    
    CMin = dataset['chlorides'].min()
    CQuartiles = percentile(dataset['chlorides'], [25, 50, 75])
    dataset.loc[ dataset['chlorides'] <= CMin, 'chlorides'] = 0
    dataset.loc[(dataset['chlorides'] > CQuartiles[0]) & 
                (dataset['chlorides'] <= CQuartiles[1]), 'chlorides']= 1
    dataset.loc[(dataset['chlorides'] > CQuartiles[1]) & 
                (dataset['chlorides'] <= CQuartiles[2]), 'chlorides']= 2
    dataset.loc[ dataset['chlorides'] > CQuartiles[2], 'chlorides'] = 3
    dataset['chlorides'] = dataset['chlorides'].astype(int)
    
    FSDMin = dataset['free sulfur dioxide'].min()
    FSDQuartiles = percentile(dataset['free sulfur dioxide'], [25, 50, 75])
    dataset.loc[ dataset['free sulfur dioxide'] <= FSDMin, 'free sulfur dioxide'] = 0
    dataset.loc[(dataset['free sulfur dioxide'] > FSDQuartiles[0]) & 
                (dataset['free sulfur dioxide'] <= FSDQuartiles[1]), 'free sulfur dioxide']= 1
    dataset.loc[(dataset['free sulfur dioxide'] > FSDQuartiles[1]) & 
                (dataset['free sulfur dioxide'] <= FSDQuartiles[2]), 'free sulfur dioxide']= 2
    dataset.loc[ dataset['free sulfur dioxide'] > FSDQuartiles[2], 'free sulfur dioxide'] = 3
    dataset['free sulfur dioxide'] = dataset['free sulfur dioxide'].astype(int)
    
    TSDMin = dataset['total sulfur dioxide'].min()
    TSDQuartiles = percentile(dataset['total sulfur dioxide'], [25, 50, 75])
    dataset.loc[ dataset['total sulfur dioxide'] <= TSDMin, 'total sulfur dioxide'] = 0
    dataset.loc[(dataset['total sulfur dioxide'] > TSDQuartiles[0]) & 
                (dataset['total sulfur dioxide'] <= TSDQuartiles[1]), 'total sulfur dioxide']= 1
    dataset.loc[(dataset['total sulfur dioxide'] > TSDQuartiles[1]) & 
                (dataset['total sulfur dioxide'] <= TSDQuartiles[2]), 'total sulfur dioxide']= 2
    dataset.loc[ dataset['total sulfur dioxide'] > TSDQuartiles[2], 'total sulfur dioxide'] = 3
    dataset['total sulfur dioxide'] = dataset['total sulfur dioxide'].astype(int)
    
    DMin = dataset['density'].min()
    DQuartiles = percentile(dataset['density'], [25, 50, 75])
    dataset.loc[ dataset['density'] <= DMin, 'density'] = 0
    dataset.loc[(dataset['density'] > DQuartiles[0]) & 
                (dataset['density'] <= DQuartiles[1]), 'density']= 1
    dataset.loc[(dataset['density'] > DQuartiles[1]) & 
                (dataset['density'] <= DQuartiles[2]), 'density']= 2
    dataset.loc[ dataset['density'] > DQuartiles[2], 'density'] = 3
    dataset['density'] = dataset['density'].astype(int)
    
    PHMin = dataset['pH'].min()
    PHQuartiles = percentile(dataset['pH'], [25, 50, 75])
    dataset.loc[ dataset['pH'] <= PHMin, 'pH'] = 0
    dataset.loc[(dataset['pH'] > PHQuartiles[0]) & 
                (dataset['pH'] <= PHQuartiles[1]), 'pH']= 1
    dataset.loc[(dataset['pH'] > PHQuartiles[1]) & 
                (dataset['pH'] <= PHQuartiles[2]), 'pH']= 2
    dataset.loc[ dataset['pH'] > PHQuartiles[2], 'pH'] = 3
    dataset['pH'] = dataset['pH'].astype(int)
    
    SMin = dataset['sulphates'].min()
    SQuartiles = percentile(dataset['sulphates'], [25, 50, 75])
    dataset.loc[ dataset['sulphates'] <= SMin, 'sulphates'] = 0
    dataset.loc[(dataset['sulphates'] > SQuartiles[0]) & 
                (dataset['sulphates'] <= SQuartiles[1]), 'sulphates']= 1
    dataset.loc[(dataset['sulphates'] > SQuartiles[1]) & 
                (dataset['sulphates'] <= SQuartiles[2]), 'sulphates']= 2
    dataset.loc[ dataset['sulphates'] > SQuartiles[2], 'sulphates'] = 3
    dataset['sulphates'] = dataset['sulphates'].astype(int)
    
    AMin = dataset['alcohol'].min()
    AQuartiles = percentile(dataset['alcohol'], [25, 50, 75])
    dataset.loc[ dataset['alcohol'] <= AMin, 'alcohol'] = 0
    dataset.loc[(dataset['alcohol'] > AQuartiles[0]) & 
                (dataset['alcohol'] <= AQuartiles[1]), 'alcohol']= 1
    dataset.loc[(dataset['alcohol'] > AQuartiles[1]) & 
                (dataset['alcohol'] <= AQuartiles[2]), 'alcohol']= 2
    dataset.loc[ dataset['alcohol'] > AQuartiles[2], 'alcohol'] = 3
    dataset['alcohol'] = dataset['alcohol'].astype(int)
    
# Turn back into a dataframe and assign X and y value
title_list = ["fixed acidity", "volatile acidity", "citric acid", "residual sugar", 
              "chlorides", "free sulfur dioxide", "total sulfur dioxide", "density", 
              "pH", "sulphates", "alcohol", "quality"]
df = DataFrame(listData[0], columns=title_list)
X = df.iloc[:, 0:10]
y = df.iloc[:, 11]
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, 
                                                    stratify=y, random_state=0)

# Finding Clusters
km = KMeans(n_clusters=3, init='random', n_init=10, max_iter=300, tol=1e-04, 
            random_state=0)

y_km = km.fit_predict(X)

print('Distortion: %.2f' % km.inertia_)

# Elbow Method
distortions = []
for i in range(1, 11):
    km = KMeans(n_clusters=i, init='k-means++', n_init=10, max_iter=300, random_state=0)
    km.fit(X)
    distortions.append(km.inertia_)
plt.plot(range(1, 11), distortions, marker='o')
plt.xlabel('Number of clusters')
plt.ylabel('Distortion')
plt.tight_layout()
plt.show()
