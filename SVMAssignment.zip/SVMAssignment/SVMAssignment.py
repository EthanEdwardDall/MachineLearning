# SVMAssignment.py
# Ethan Dall
# 10/10/2020
# Machine Learning

# Imports
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.svm import SVC
from sklearn.metrics import accuracy_score
from sklearn.model_selection import train_test_split
from sklearn.linear_model import Perceptron
from sklearn.preprocessing import StandardScaler

# This method will return the value calculated by the accuracy_score() method
def calculateAccuracy(X, y):
    # Test Train Split
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=1, stratify=y)
    
    # Initialize Perceptron and Scaler
    ppn = Perceptron(eta0=0.1, random_state=1)
    sc = StandardScaler()
    sc.fit(X_test)
    sc.fit(X_train)
    X_train_std = sc.transform(X_train)
    X_test_std = sc.transform(X_test)
    
    # Get X_test_std
    X_test_std = sc.transform(X_test)
    ppn.fit(X_train_std, y_train)
    y_pred = ppn.predict(X_test_std)
    
    return accuracy_score(y_test, y_pred)

""" Assign Data """
# Call the Banknote file for pandas
data = pd.read_csv('DBA.txt', header=None)

# shuffle the DataFrame rows 
data = data.sample(frac = 1)
classifier = SVC(kernel="linear")

"""Feature Combo #1"""
# Assign Data
XOne = data.iloc[0:50, [0,1]].values
yOne = data.iloc[0:50, 4].values

# Scatter
fig, ax = plt.subplots(nrows=2, ncols=2, figsize=(10, 10))
m,n = XOne.shape[0],XOne.shape[1]
pos,neg= (yOne==1).reshape(m,1), (yOne==0).reshape(m,1)
ax[0][0].scatter(XOne[pos[:,0],0],XOne[pos[:,0],1],c="r",marker="+",s=50)
ax[0][0].scatter(XOne[neg[:,0],0],XOne[neg[:,0],1],c="y",marker="o",s=50)
ax[0][0].set_title('Combo #1')

# C = 1
classifier.fit(XOne,np.ravel(yOne))
ax[0][1].scatter(XOne[pos[:,0],0],XOne[pos[:,0],1],c="r",marker="+",s=50)
ax[0][1].scatter(XOne[neg[:,0],0],XOne[neg[:,0],1],c="y",marker="o",s=50)

# plotting the decision boundary
X_1,X_2 = np.meshgrid(np.linspace(XOne[:,0].min(),XOne[:,1].max(),num=100),np.linspace(XOne[:,1].min(),XOne[:,1].max(),num=100))
ax[0][1].contour(X_1,X_2,classifier.predict(np.array([X_1.ravel(),X_2.ravel()]).T).reshape(X_1.shape),1,colors="b")
ax[0][1].set_title('C = 1')

# C = 100
classifier2 = SVC(C=100,kernel="linear")
classifier2.fit(XOne, np.ravel(yOne))
ax[1][0].scatter(XOne[pos[:,0],0],XOne[pos[:,0],1],c="r",marker="+",s=50)
ax[1][0].scatter(XOne[neg[:,0],0],XOne[neg[:,0],1],c="y",marker="o",s=50)

# plotting the decision boundary
X_1,X_2 = np.meshgrid(np.linspace(XOne[:,0].min(),XOne[:,1].max(),num=100),np.linspace(XOne[:,1].min(),XOne[:,1].max(),num=100))
ax[1][0].contour(X_1,X_2,classifier2.predict(np.array([X_1.ravel(),X_2.ravel()]).T).reshape(X_1.shape),1,colors="b")
ax[1][0].set_title('C = 100')

# C = 500
classifier3 = SVC(C=500,kernel="linear")
classifier3.fit(XOne, np.ravel(yOne))
ax[1][1].scatter(XOne[pos[:,0],0],XOne[pos[:,0],1],c="r",marker="+",s=50)
ax[1][1].scatter(XOne[neg[:,0],0],XOne[neg[:,0],1],c="y",marker="o",s=50)

# plotting the decision boundary
X_1,X_2 = np.meshgrid(np.linspace(XOne[:,0].min(),XOne[:,1].max(),num=100),np.linspace(XOne[:,1].min(),XOne[:,1].max(),num=100))
ax[1][1].contour(X_1,X_2,classifier3.predict(np.array([X_1.ravel(),X_2.ravel()]).T).reshape(X_1.shape),1,colors="b")
ax[1][1].set_title('C = 500')

# Calculate Accuracy
print('Combo #1 Accuracy: %.2f' % calculateAccuracy(XOne, yOne))


"""Feature Combo #2"""
# Assign Data
XTwo = data.iloc[0:len(data), [0,2]].values
yTwo = data.iloc[0:len(data), 4].values

# Scatter
m2,n2 = XTwo.shape[0],XTwo.shape[1]
pos2,neg2= (yTwo==1).reshape(m2,1), (yTwo==0).reshape(m2,1)
fig2, ax2 = plt.subplots(nrows=2, ncols=2, figsize=(10, 10))
ax2[0][0].scatter(XTwo[pos2[:,0],0],XTwo[pos2[:,0],1],c="r",marker="+")
ax2[0][0].scatter(XTwo[neg2[:,0],0],XTwo[neg2[:,0],1],c="y",marker="o")
ax2[0][0].set_title('Combo #2')

# Gamma = 30
classifier4 = SVC(kernel="rbf",gamma=30)
classifier4.fit(XTwo,yTwo.ravel())
ax2[0][1].scatter(XTwo[pos2[:,0],0],XTwo[pos2[:,0],1],c="r",marker="+")
ax2[0][1].scatter(XTwo[neg2[:,0],0],XTwo[neg2[:,0],1],c="y",marker="o")
ax2[0][1].set_title('Gamma = 30')


# plotting the decision boundary
X_5,X_6 = np.meshgrid(np.linspace(XTwo[:,0].min(),XTwo[:,1].max(),num=100),np.linspace(XTwo[:,1].min(),XTwo[:,1].max(),num=100))
ax2[0][1].contour(X_5,X_6,classifier4.predict(np.array([X_5.ravel(),X_6.ravel()]).T).reshape(X_5.shape),1,colors="b")

# Gamma = 120
classifier5 = SVC(kernel="rbf",gamma=120)
classifier5.fit(XTwo,yTwo.ravel())
ax2[1][0].scatter(XTwo[pos2[:,0],0],XTwo[pos2[:,0],1],c="r",marker="+")
ax2[1][0].scatter(XTwo[neg2[:,0],0],XTwo[neg2[:,0],1],c="y",marker="o")
ax2[1][0].set_title('Gamma = 120')


# plotting the decision boundary
X_5,X_6 = np.meshgrid(np.linspace(XTwo[:,0].min(),XTwo[:,1].max(),num=100),np.linspace(XTwo[:,1].min(),XTwo[:,1].max(),num=100))
ax2[1][0].contour(X_5,X_6,classifier5.predict(np.array([X_5.ravel(),X_6.ravel()]).T).reshape(X_5.shape),1,colors="b")

# Gamma = 240
classifier6 = SVC(kernel="rbf",gamma=240)
classifier6.fit(XTwo,yTwo.ravel())
ax2[1][1].scatter(XTwo[pos2[:,0],0],XTwo[pos2[:,0],1],c="r",marker="+")
ax2[1][1].scatter(XTwo[neg2[:,0],0],XTwo[neg2[:,0],1],c="y",marker="o")
ax2[1][1].set_title('Gamma = 240')


# plotting the decision boundary
X_5,X_6 = np.meshgrid(np.linspace(XTwo[:,0].min(),XTwo[:,1].max(),num=100),np.linspace(XTwo[:,1].min(),XTwo[:,1].max(),num=100))
ax2[1][1].contour(X_5,X_6,classifier6.predict(np.array([X_5.ravel(),X_6.ravel()]).T).reshape(X_5.shape),1,colors="b")

# Calculate Accuracy
print('Combo #2 Accuracy: %.2f' % calculateAccuracy(XTwo, yTwo))

"""Feature Combo #3"""
# Assign Data
XThree = data.iloc[0:len(data), [0,3]].values
yThree = data.iloc[0:len(data), 4].values

# Scatter
m3,n3 = XThree.shape[0],XThree.shape[1]
pos3,neg3= (yThree==1).reshape(m3,1), (yThree==0).reshape(m3,1)
fig3, ax3 = plt.subplots(nrows=2, ncols=2, figsize=(10, 10))
ax3[0][0].scatter(XThree[pos3[:,0],0],XThree[pos3[:,0],1],c="r",marker="+")
ax3[0][0].scatter(XThree[neg3[:,0],0],XThree[neg3[:,0],1],c="y",marker="o")
ax3[0][0].set_title('Combo #3')

# Gamma = 30, C = 1
classifier7 = SVC(C = 1, kernel="rbf", gamma=30)
classifier7.fit(XThree,yThree.ravel())
ax3[0][1].scatter(XThree[pos3[:,0],0],XThree[pos3[:,0],1],c="r",marker="+")
ax3[0][1].scatter(XThree[neg3[:,0],0],XThree[neg3[:,0],1],c="y",marker="o")
ax3[0][1].set_title('C = 1, G = 30')


# plotting the decision boundary
X_5,X_6 = np.meshgrid(np.linspace(XThree[:,0].min(),XThree[:,1].max(),num=100),np.linspace(XThree[:,1].min(),XThree[:,1].max(),num=100))
ax3[0][1].contour(X_5,X_6,classifier7.predict(np.array([X_5.ravel(),X_6.ravel()]).T).reshape(X_5.shape),1,colors="b")

# Gamma = 120, C = 100
classifier8 = SVC(C = 100, kernel="rbf", gamma=120)
classifier8.fit(XThree,yThree.ravel())
ax3[1][0].scatter(XThree[pos3[:,0],0],XThree[pos3[:,0],1],c="r",marker="+")
ax3[1][0].scatter(XThree[neg3[:,0],0],XThree[neg3[:,0],1],c="y",marker="o")
ax3[1][0].set_title('C = 100, G = 120')


# plotting the decision boundary
X_5,X_6 = np.meshgrid(np.linspace(XThree[:,0].min(),XThree[:,1].max(),num=100),np.linspace(XThree[:,1].min(),XThree[:,1].max(),num=100))
ax3[1][0].contour(X_5,X_6,classifier8.predict(np.array([X_5.ravel(),X_6.ravel()]).T).reshape(X_5.shape),1,colors="b")

# Gamma = 240, C = 500
classifier9 = SVC(C = 500, kernel="rbf", gamma=240)
classifier9.fit(XThree,yThree.ravel())
ax3[1][1].scatter(XThree[pos3[:,0],0],XThree[pos3[:,0],1],c="r",marker="+")
ax3[1][1].scatter(XThree[neg3[:,0],0],XThree[neg3[:,0],1],c="y",marker="o")
ax3[1][1].set_title('C = 500, G = 240')


# plotting the decision boundary
X_5,X_6 = np.meshgrid(np.linspace(XThree[:,0].min(),XThree[:,1].max(),num=100),np.linspace(XThree[:,1].min(),XThree[:,1].max(),num=100))
ax3[1][1].contour(X_5,X_6,classifier9.predict(np.array([X_5.ravel(),X_6.ravel()]).T).reshape(X_5.shape),1,colors="b")

# Calculate Accuracy
print('Combo #3 Accuracy: %.2f' % calculateAccuracy(XThree, yThree))