# MLProgrammingTwo.py
# Ethan Dall
# 10/04/2020
# Machine Learning

# Imports
import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.linear_model import LogisticRegression
from sklearn.preprocessing import StandardScaler
from matplotlib.colors import ListedColormap
import matplotlib.pyplot as plt


def plot_decision_regions(X, y, classifier, test_idx=None, resolution=0.02):

    # setup marker generator and color map
    markers = ('s', 'x', 'o', '^', 'v')
    colors = ('red', 'blue', 'lightgreen', 'gray', 'cyan')
    cmap = ListedColormap(colors[:len(np.unique(y))])

    # plot the decision surface
    x1_min, x1_max = X[:, 0].min() - 1, X[:, 0].max() + 1
    x2_min, x2_max = X[:, 1].min() - 1, X[:, 1].max() + 1
    xx1, xx2 = np.meshgrid(np.arange(x1_min, x1_max, resolution),
                           np.arange(x2_min, x2_max, resolution))
    Z = classifier.predict(np.array([xx1.ravel(), xx2.ravel()]).T)
    Z = Z.reshape(xx1.shape)
    plt.contourf(xx1, xx2, Z, alpha=0.3, cmap=cmap)
    plt.xlim(xx1.min(), xx1.max())
    plt.ylim(xx2.min(), xx2.max())

    for idx, cl in enumerate(np.unique(y)):
        plt.scatter(x=X[y == cl, 0], 
                    y=X[y == cl, 1],
                    alpha=0.8, 
                    c=colors[idx],
                    marker=markers[idx], 
                    label=cl, 
                    edgecolor='black')

    # highlight test samples
    if test_idx:
        # plot all samples
        X_test, y_test = X[test_idx, :], y[test_idx]

        plt.scatter(X_test[:, 0],
                    X_test[:, 1],
                    c='',
                    edgecolor='black',
                    alpha=1.0,
                    linewidth=1,
                    marker='o',
                    s=100, 
                    label='test set')

# This method computes the Cost given the size of the theta and X,Y
def computeCost(X,Y,theta):
    m = len(Y)
    predictions = X.dot(theta)
    square_err = (predictions - Y)**2
    
    return 1/(2*m) * np.sum(square_err)

# This method computes the descent value using X,Y the size of theta, alpha gradient, and amount of num
def gradientDescent(X,Y,theta,alpha,num_iters):
    m = len(Y)
    descentList = []
    
    for i in range(num_iters):
        predictions = X.dot(theta)
        error = np.dot(X.transpose(),(predictions - Y))
        descent = alpha * 1/m * error
        theta -= descent
        descentList.append(computeCost(X,Y,theta))
    
    return theta, descentList

# Main
# Assign Data
data = pd.read_csv("SAI.txt")
X = data.iloc[0:len(data), 0].values
Y = data.iloc[0:len(data), 1].values

# Shows the size and train result for X and Y arrays for SAI document data
X_train, X_test, Y_train, Y_test = train_test_split(X, Y, test_size=0.1)
print("X and Y Train and Test Size Comparison:")
print('X-train size:', X_train.size)
print('X-test size:', X_test.size)
print('Y-train size:', Y_train.size)
print('Y-test size:', Y_test.size)

# Linear Regression alpha, beta, and confidence
linReg = LinearRegression()

# Reshape for 2D Array
X_train = X_train.reshape(-1,1)
X_test = X_test.reshape(-1,1)
Y_train = Y_train.reshape(-1,1)
Y_test = Y_test.reshape(-1,1)

model = linReg.fit(X_train, Y_train)
confidence = linReg.score(X_test, Y_test)



print("\nLinear Regression Model Data:\n" f'alpha = {model.intercept_}')
print(f'betas = {model.coef_}')
print("Confidence:", str(confidence))

# Cost computation
m_Cost = len(X)
X_Cost = np.append(np.ones((m_Cost,1)),X.reshape(m_Cost,1),axis=1)
Y_Cost = Y.reshape(m_Cost,1)
theta = np.zeros((2,1))

print("Cost:", computeCost(X_Cost,Y_Cost,theta))

# Gradient Descent
theta, history = gradientDescent(X_Cost,Y_Cost,theta,0.01,len(data))
print("Gradient Descent:", "h(x) ="+str(round(theta[0,0],2))+" + "+str(round(theta[1,0],2))+"x1")

# Create a Plot for the Cost + Gradient Descent
fig = plt.figure()
plt.plot(history)
plt.xlabel("Iteration")
plt.ylabel("$J(\Theta)$")
plt.title("Cost function using Gradient Descent")

# Assign Data
dataSet = pd.read_csv("PID.txt")
X = dataSet.iloc[:, [0,7]]
Y = dataSet.iloc[:, 8]

print("\n" + 'Indian Diabeties Database data size:', len(dataSet))
print('feature X size:', len(X))
print('class label y size:', len(Y))
print('Class labels:', np.unique(Y))

# Shows the size and train result for X and Y arrays for PID document data
X_train, X_test, Y_train, Y_test = train_test_split(X, Y, test_size=0.3, random_state=1, stratify=Y)
print("\nX and Y Train and Test Size comparison:")
print('X-train size', X_train.size)
print('X-test size', X_test.size)
print('Y-train size', Y_train.size)
print('Y-test size', Y_test.size)

# Scale fit then transform
sc = StandardScaler()
sc.fit(X_train)
sc.fit(X_test)
X_train_std = sc.transform(X_train)
X_test_std = sc.transform(X_test)
X_combined_std = np.vstack((X_train_std, X_test_std))
Y_combined = np.hstack((Y_train, Y_test))
lr = LogisticRegression(C=100.0, random_state=1)
lr.fit(X_train_std, Y_train)

plot_decision_regions(X_combined_std, Y_combined,classifier=lr, test_idx=range(105, 150))
plt.xlabel('X')
plt.ylabel('Y')
plt.legend(loc='upper left')
plt.tight_layout()
plt.show()